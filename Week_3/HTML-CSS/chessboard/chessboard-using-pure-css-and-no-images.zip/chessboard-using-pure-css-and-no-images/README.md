# Chessboard using Pure css and No Images.

A Pen created on CodePen.io. Original URL: [https://codepen.io/smabe/pen/xxEWjeO](https://codepen.io/smabe/pen/xxEWjeO).

A Chessboard with all the pieces. Knight, Queen, Bishop, Horse, Pawn etc..

Credit :  http://code2care.org/pages/chessboard-with-pieces-using-pure-html-and-css/